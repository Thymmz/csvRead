package com.walmart.filequeuedatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileQueueDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileQueueDatabaseApplication.class, args);
	}

}
